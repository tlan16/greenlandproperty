<?php

define('AVIATORS_DIR', get_template_directory() . '/aviators');

require_once 'core/core.php';

aviators_core_load_plugins();